package client;

public interface ReportFactory {
	public Report getReport();
}
